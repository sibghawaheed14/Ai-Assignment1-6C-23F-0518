import pygame
import sys

from algorithms.bfs import bfs
from algorithms.dfs import dfs
from algorithms.ucs import ucs
from algorithms.dls import dls
from algorithms.iddfs import iddfs
from algorithms.bidirectional import bidirectional

pygame.init()

ROWS = 8
COLS = 10
CELL_SIZE = 70

WIDTH = COLS * CELL_SIZE
HEIGHT = ROWS * CELL_SIZE

WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("AI Pathfinder")

WHITE = (255,255,255)
BLACK = (0,0,0)
GREEN = (0,255,0)
RED = (255,0,0)
GRAY = (100,100,100)
BLUE = (0,0,255)
YELLOW = (255,255,0)
PURPLE = (128,0,128)

grid = [[0 for _ in range(COLS)] for _ in range(ROWS)]

start = (5,7)
target = (6,1)
grid[1][5] = 1
grid[2][5] = 1
grid[3][5] = 1
grid[4][5] = 1
grid[5][5] = 1
grid[6][5] = 1
frontier_nodes = []
explored_nodes = []
final_path = []

def get_neighbors(node):
    row, col = node

    directions = [
        (-1,0),(0,1),(1,0),(1,1),
        (0,-1),(-1,-1),(-1,1),(1,-1)
    ]

    neighbors = []
    for dr, dc in directions:
        r, c = row+dr, col+dc
        if 0<=r<ROWS and 0<=c<COLS:
            if grid[r][c] != 1:
                neighbors.append((r,c))
    return neighbors

def update_visual(frontier, explored, path):
    global frontier_nodes, explored_nodes
    frontier_nodes = frontier
    explored_nodes = explored
    draw()

def draw():
    WIN.fill(WHITE)

    for r in range(ROWS):
        for c in range(COLS):

            color = WHITE

            if grid[r][c]==1:
                color = RED
            if (r,c) in explored_nodes:
                color = YELLOW
            if (r,c) in frontier_nodes:
                color = GRAY
            if (r,c) in final_path:
                color = PURPLE
            if (r,c)==start:
                color = GREEN
            if (r,c)==target:
                color = BLUE

            pygame.draw.rect(WIN,color,
                (c*CELL_SIZE,r*CELL_SIZE,CELL_SIZE,CELL_SIZE))
            pygame.draw.rect(WIN,BLACK,
                (c*CELL_SIZE,r*CELL_SIZE,CELL_SIZE,CELL_SIZE),1)

    pygame.display.update()

clock = pygame.time.Clock()
run = True

while run:
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:

            if event.key == pygame.K_1:
                final_path = bfs(start,target,get_neighbors,update_visual)

            if event.key == pygame.K_2:
                final_path = dfs(start,target,get_neighbors,update_visual)

            if event.key == pygame.K_3:
                final_path = ucs(start,target,get_neighbors,update_visual)

            if event.key == pygame.K_4:
                final_path = dls(start,target,get_neighbors,update_visual)

            if event.key == pygame.K_5:
                final_path = iddfs(start,target,get_neighbors,update_visual)

            if event.key == pygame.K_6:
                final_path = bidirectional(start,target,get_neighbors,update_visual)

    draw()

pygame.quit()
sys.exit()
