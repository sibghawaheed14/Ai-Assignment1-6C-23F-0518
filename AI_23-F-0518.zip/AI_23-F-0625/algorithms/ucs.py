import pygame
import time
import heapq

def ucs(start, target, get_neighbors, draw_callback):

    pq = []
    heapq.heappush(pq, (0, start))

    visited = set()
    parent = {}
    cost = {start: 0}

    frontier = []
    explored = []

    while pq:
        current_cost, current = heapq.heappop(pq)

        if current in visited:
            continue

        visited.add(current)
        explored.append(current)

        if current == target:
            break

        for neighbor in get_neighbors(current):
            new_cost = current_cost + 1

            if neighbor not in cost or new_cost < cost[neighbor]:
                cost[neighbor] = new_cost
                parent[neighbor] = current
                heapq.heappush(pq, (new_cost, neighbor))

        frontier = [node for _, node in pq]
        draw_callback(frontier, explored, [])
        pygame.display.update()
        time.sleep(0.1)

    return reconstruct_path(parent, start, target)


def reconstruct_path(parent, start, target):
    path = []
    node = target
    while node in parent:
        path.append(node)
        node = parent[node]
    path.append(start)
    path.reverse()
    return path
