from algorithms.dls import dls

def iddfs(start, target, get_neighbors, draw_callback, max_depth=20):

    for depth in range(max_depth):
        path = dls(start, target, get_neighbors, draw_callback, limit=depth)
        if path and path[-1] == target:
            return path

    return []
