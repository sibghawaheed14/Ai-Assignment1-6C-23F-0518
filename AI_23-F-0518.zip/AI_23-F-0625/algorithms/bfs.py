from collections import deque
import pygame
import time

def bfs(start, target, get_neighbors, draw_callback):

    queue = deque([start])
    visited = set([start])
    parent = {}

    frontier = []
    explored = []

    while queue:
        current = queue.popleft()
        explored.append(current)

        if current == target:
            break

        for neighbor in get_neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                parent[neighbor] = current
                queue.append(neighbor)

        frontier = list(queue)
        draw_callback(frontier, explored, [])
        pygame.display.update()
        time.sleep(0.1)

    return reconstruct_path(parent, start, target)


def reconstruct_path(parent, start, target):
    path = []
    node = target
    while node in parent:
        path.append(node)
        node = parent[node]
    path.append(start)
    path.reverse()
    return path
