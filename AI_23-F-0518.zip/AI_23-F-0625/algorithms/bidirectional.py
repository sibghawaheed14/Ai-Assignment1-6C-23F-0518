import pygame
import time
from collections import deque

def bidirectional(start, target, get_neighbors, draw_callback):

    q_start = deque([start])
    q_target = deque([target])

    parent_start = {}
    parent_target = {}

    visited_start = {start}
    visited_target = {target}

    meeting = None

    while q_start and q_target:

        current_start = q_start.popleft()
        for neighbor in get_neighbors(current_start):
            if neighbor not in visited_start:
                visited_start.add(neighbor)
                parent_start[neighbor] = current_start
                q_start.append(neighbor)

            if neighbor in visited_target:
                meeting = neighbor
                break

        if meeting:
            break

        current_target = q_target.popleft()
        for neighbor in get_neighbors(current_target):
            if neighbor not in visited_target:
                visited_target.add(neighbor)
                parent_target[neighbor] = current_target
                q_target.append(neighbor)

            if neighbor in visited_start:
                meeting = neighbor
                break

        draw_callback(list(q_start)+list(q_target),
                      list(visited_start)+list(visited_target),
                      [])
        pygame.display.update()
        time.sleep(0.1)

        if meeting:
            break

    if not meeting:
        return []

    # reconstruct path
    path = []

    node = meeting
    while node in parent_start:
        path.append(node)
        node = parent_start[node]
    path.append(start)
    path.reverse()

    node = meeting
    while node in parent_target:
        node = parent_target[node]
        path.append(node)

    return path
