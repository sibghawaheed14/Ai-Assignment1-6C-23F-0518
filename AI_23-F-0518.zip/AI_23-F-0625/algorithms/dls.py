import pygame
import time

def dls(start, target, get_neighbors, draw_callback, limit=10):

    stack = [(start, 0)]
    parent = {}
    visited = set([start])

    frontier = []
    explored = []

    while stack:
        current, depth = stack.pop()
        explored.append(current)

        if current == target:
            break

        if depth < limit:
            for neighbor in reversed(get_neighbors(current)):
                if neighbor not in visited:
                    visited.add(neighbor)
                    parent[neighbor] = current
                    stack.append((neighbor, depth + 1))

        frontier = [node for node, _ in stack]
        draw_callback(frontier, explored, [])
        pygame.display.update()
        time.sleep(0.1)

    return reconstruct_path(parent, start, target)


def reconstruct_path(parent, start, target):
    path = []
    node = target
    while node in parent:
        path.append(node)
        node = parent[node]
    path.append(start)
    path.reverse()
    return path
